;(function ($, window, document, undefined) {
    var $win = $(window);
    var $doc = $(document);

    "use strict";
    $doc.ready(function () {


    });


})(jQuery, window, document);
